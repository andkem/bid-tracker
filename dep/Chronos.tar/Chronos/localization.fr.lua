-- Version : French ( by Vjeux, Sasmira )
-- Last Update : 03/21/2005

if ( GetLocale() == "frFR" ) then

	-- Chat Configuration
	SCHEDULE_COMM		= {"/dans","/pause"};
	SCHEDULE_DESC		= "/dans <secondes> <commande> [<args> ...]";
	SCHEDULE_USAGE1		= "Utilisation : /dans <secondes> <commande> [<args> ...]";
	SCHEDULE_USAGE2		= "Lance la <commande> avec les arguments <args> apr\195\168s <secondes> secondes.";

end