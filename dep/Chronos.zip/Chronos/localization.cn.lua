--------------------------------------------------
-- localization.cn.lua (Chinese)
-- $LastChangedBy: Gryphon $
-- $Date: 2007-02-02 16:41:28 -0600 (Fri, 02 Feb 2007) $
-- Translation:

if ( GetLocale() == "zhCN" ) then

	-- Please submit your translation to karlkfi@yahoo.com

end
