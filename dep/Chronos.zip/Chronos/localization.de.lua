-- Version : German (by pc, StarDust)
-- Last Update : 02/17/2005

if ( GetLocale() == "deDE" ) then

	-- Chat Configuration
	SCHEDULE_COMM		= {"/in","/pause","/verz\195\182gern"};
	SCHEDULE_DESC		= "/in <Sekunden> <Befehl> [<Param> ...]";
	SCHEDULE_USAGE1		= "Funktionsweise: /in <Sekunden> <Befehl> [<Param> ...] |cFFCC9966[Hinweis: /in KANN KEINE Zauber wirken um die Erstellung von Bots zu verhindern]|r";
	SCHEDULE_USAGE2		= "Startet <Befehl> mit den Parametern <Param> nach <Sekunden> Sekunden.";

end